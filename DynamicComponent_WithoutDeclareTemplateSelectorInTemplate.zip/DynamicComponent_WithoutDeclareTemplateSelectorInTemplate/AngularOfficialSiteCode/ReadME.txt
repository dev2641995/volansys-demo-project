For this project,

1) run "npm install"
2) run "npm start"