"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AdItem = (function () {
    function AdItem(component, data) {
        this.component = component;
        this.data = data;
    }
    return AdItem;
}());
exports.AdItem = AdItem;
//# sourceMappingURL=ad-item.js.map