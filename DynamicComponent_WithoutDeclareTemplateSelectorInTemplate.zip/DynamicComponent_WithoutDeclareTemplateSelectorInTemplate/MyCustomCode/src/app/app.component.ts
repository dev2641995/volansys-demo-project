import { Component } from '@angular/core';
import { HelloWorldComponent } from './hello-world/hello-world.component';
import { WorldHelloComponent } from './world-hello/world-hello.component';
import { AdsComponent } from './ads/ads.component';
import { dynamicAdsData } from './data-for-ads';

@Component({
  selector: 'app-root',
  template: `
    <div>
      <h2>Lets dynamically create some components!</h2>
      <button (click)="createHelloWorldComponent()">Create Hello World</button>
      <button (click)="createWorldHelloComponent()">Create World Hello</button>
      <button (click)="callInterval()">Create Ads</button>
      <dynamic-component [componentData]="componentData"></dynamic-component>
    </div>
  `
})
export class AppComponent {
  componentData = null;
  adsCounter: number = 0;
  interval: any;

  createHelloWorldComponent() {
    clearInterval(this.interval);
    this.componentData = {
      component: HelloWorldComponent,
      inputs: {
        data: {
          showNum: 9
        }
      }
    };
  }

  createWorldHelloComponent() {
    clearInterval(this.interval);
    this.componentData = {
      component: WorldHelloComponent,
      inputs: {
        data: {
          showNum: 2
        }
      }
    };
  }

  prepareDataForcreateAdsComponent() {
    let prepareData = dynamicAdsData[this.adsCounter++];
    if (this.adsCounter == 4) {
      this.adsCounter = 0;
    }
    this.createAdsComponent(prepareData);
  }

  callInterval() {
    clearInterval(this.interval);
    this.interval = setInterval(() => {
      this.prepareDataForcreateAdsComponent();
    }, 3000);
  }

  createAdsComponent(getComponentData) {
    this.componentData = {
      component: AdsComponent,
      inputs: {
        data: getComponentData
      }
    };
  }
}
