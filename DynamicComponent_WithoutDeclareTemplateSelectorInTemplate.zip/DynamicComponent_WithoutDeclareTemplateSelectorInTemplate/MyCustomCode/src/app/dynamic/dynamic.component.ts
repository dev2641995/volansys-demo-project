import {
  Component,
  ViewChild,
  Input,
  ViewContainerRef,
  ReflectiveInjector,
  ComponentFactoryResolver
} from '@angular/core';
import { HelloWorldComponent } from '../hello-world/hello-world.component';
import { WorldHelloComponent } from '../world-hello/world-hello.component';
import { AdsComponent } from '../ads/ads.component'; 
import { AdHostDirective } from '../ad-host.directive';

@Component({
  selector: 'dynamic-component',
  entryComponents: [HelloWorldComponent, WorldHelloComponent, AdsComponent],
  /* IF THIS entryComponents IS NOT DEFINE IN ANY .module.ts FILE, THEN YOU NEED TO DEFINE Input
  HERE, BETTER IS DEFINE IT HERE INSTEAD OF .module.ts */
  template: `
    <ng-template appAdHost></ng-template>
  `
})
export class DynamicComponent {
  componentFactory: any;
  @ViewChild(AdHostDirective) adHost: AdHostDirective;

  constructor(private resolver: ComponentFactoryResolver) { }

  @Input() set componentData(data: { component: any, inputs: any }) {
    if (!data) {
      return;
    }

    // We create a factory out of the component we want to create
    let factory = this.resolver.resolveComponentFactory(data.component);
    this.componentFactory = factory;

    this.showMyDynamicComponent(data.inputs.data);
  }

  showMyDynamicComponent(getData) {
    let viewContainerRef = this.adHost.viewContainerRef;
    viewContainerRef.clear(); /* DESTROY THE OLD COMPONENT...IF YOU DON'T WRITE THIS STATEMENT
                                 THEN IT APPENDS THE COMPONENT */
    let componentRef = viewContainerRef.createComponent(this.componentFactory);
    (<{ data: { component: any, inputs: any } }>componentRef.instance).data = getData;
  }

}
