import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-world-hello',
  template: `
    <div>World Hello {{data.showNum}}</div>
  `
})
export class WorldHelloComponent {
  @Input() data: any;
}
