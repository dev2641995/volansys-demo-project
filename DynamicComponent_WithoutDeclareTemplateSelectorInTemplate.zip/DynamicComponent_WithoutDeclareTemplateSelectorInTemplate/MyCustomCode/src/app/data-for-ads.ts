export const dynamicAdsData = [
    { banner:1, name: 'Bombasto', bio: 'Brave as they come' },
    { banner:1, name: 'Dr IQ', bio: 'Smart as they come'},
    { banner:2, headline: 'Hiring for several positions', body: 'Submit your resume today!'},
    { banner:2, headline: 'Openings in all departments', body: 'Apply today'}
];
