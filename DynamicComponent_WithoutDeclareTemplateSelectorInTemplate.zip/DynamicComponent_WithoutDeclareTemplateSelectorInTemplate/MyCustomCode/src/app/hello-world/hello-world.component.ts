import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-hello-world',
  template: `
    <div>Hello World {{data.showNum}}</div>
  `
})
export class HelloWorldComponent {
  
  @Input() data: any;

}
