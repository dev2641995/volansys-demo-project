import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HelloWorldComponent } from './hello-world/hello-world.component';
import { WorldHelloComponent } from './world-hello/world-hello.component';
import { DynamicComponent } from './dynamic/dynamic.component';
import { AdHostDirective } from './ad-host.directive';
import { AdsComponent } from './ads/ads.component';

@NgModule({
  declarations: [
    AppComponent,
    HelloWorldComponent,
    WorldHelloComponent,
    DynamicComponent,
    AdHostDirective,
    AdsComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  // entryComponents: [HelloWorldComponent, WorldHelloComponent, AdsComponent]
  /* YOU CAN DEFINE entryComponents HERE...BUT BETTER IS DEFINE IT THERE WHERE YOU WANT TO USE,
  IN THIS CASE, entryComponents DEFINE IN dynamic.component.ts file */
})
export class AppModule { }
